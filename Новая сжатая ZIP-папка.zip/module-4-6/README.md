# привет))

## Команда для скачивания

```
git clone https://github.com/DonOutcast/module-4-6.git
```

## Команда для запуска

```angular2html
cd advertisement
python manage.py runserver
```
