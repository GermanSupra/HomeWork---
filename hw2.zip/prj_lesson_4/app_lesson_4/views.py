from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.

def index(request):
    return HttpResponse("""
        <h1 style='background-color: lightgreen; padding: 4vh; border-radius: 10px'><i>Домашка по 4 занятию</i></h1>
    """)