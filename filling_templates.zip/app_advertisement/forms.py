from django import forms


class AdvertisementForm(forms.Form):
    title = forms.CharField(max_length=60, label="Заголовок",
                            widget=forms.TextInput(attrs={"class": "form-control form-control-lg"}))
    
    description = forms.CharField(widget=forms.Textarea(attrs={"class": "form-control form-control-lg"}), label='Описание')

    price = forms.DecimalField(label='Цена', widget=forms.NumberInput(attrs={"class": "form-control form-control-lg"}))
    auction = forms.BooleanField(label='Возможность торга', widget=forms.CheckboxInput(attrs={"class": "form-control form-control-lg"}))
    image = forms.ImageField(label='Фотография', widget=forms.FileInput(attrs={"class": "form-control form-control-lg"}))